#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  5 10:38:45 2018

@author: root
"""
import configparser
import json
import sys
import tensorflow as tf
from keras import losses
import keras.backend as K

loss_dict = {'dispersion_loss':[],'binary_loss':[]}

def tf_print(op, tensors, message=None):
    def print_message(x):
        #sys.stdout.write(message + " %s\n" % x)
        loss_dict[message].append(float(x))
        with open('loss.json','w+') as file:
            json.dump(loss_dict, file, indent=4)
        return x

    prints = [tf.py_func(print_message, [tensor], tensor.dtype) for tensor in tensors]
    with tf.control_dependencies(prints):
        op = tf.identity(op)
    return op

### Average distance from the Center of Mass
def com(G_out, weight, round_up):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        center = tf.reduce_mean(G_out, axis=0, keepdims=True)
        distance_xy = tf.square(tf.subtract(G_out,center))
        distance = tf.reduce_sum(distance_xy, 1)
        avg_distance = tf.reduce_mean(tf.sqrt(distance))
        loss_d = tf.reciprocal(avg_distance)
        
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss
