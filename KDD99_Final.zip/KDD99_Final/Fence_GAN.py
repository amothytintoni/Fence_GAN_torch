#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 28 18:19:28 2018

@author: valaxw
"""
import keras.backend as K
import datetime
import os
import random
import configparser

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

import tensorflow as tf
from keras import losses
from keras.layers import Dense, Dropout, Input, LeakyReLU
from keras.models import Model
from keras.optimizers import Adam, SGD, Adamax
from keras import regularizers

from numpy.random import seed
seed(1)
from tensorflow import set_random_seed
set_random_seed(1)
K.clear_session()
time = str(datetime.datetime.now())

pic_path = './experiments/' + time + '/pictures/'
result_path = './experiments/' + time + '/results/'
model_path = './experiments/' + time + '/model_weights/'
data_path = './Dataset/'

x_test_normal = np.load(os.path.join(data_path,'X_test_normal.npy'))
x_test_anomaly = np.load(os.path.join(data_path,'X_test_anomaly.npy'))
x_train_normal = np.load(os.path.join(data_path,'X_train_normal.npy'))
x_train_anomaly = np.load(os.path.join(data_path,'X_train_anomaly.npy'))

#Setup
z_dim = 32 #32
epochs = 50
batch_size = 256
l2_reg = 0
dropout = 0.2
lr_G = 0.002
lr_D = 0.01
g_objective_anneal = 1 #1 if no anneal
repeat = 4 #Only matters if g_objective_anneal != 1
baseline = 0.5 #Generator Label if no annealing, else it is the minimum label for generator
lr_anneal = 0
dispersion_weight = 30
gen_weight = 0.5
#threshold = 0.5 #Threshold for classification
from custom_losses import com
loss_type = com
    
if not os.path.exists(pic_path):
    os.makedirs(pic_path)
if not os.path.exists(result_path):
    os.makedirs(result_path)
if not os.path.exists(model_path):
    os.makedirs(model_path)


def noise_z(n):
    return np.random.normal(0, 1, [n, z_dim])

def label_annealing(epoch, repeat, g_objective_anneal, baseline):
    x = (epoch + 1) % repeat
    if g_objective_anneal == 1:
        label = baseline
    else:
        label = min(1, baseline + pow(np.e, (-(g_objective_anneal)) * x))
    return label

def histogram(D, v_histogram, status, epoch):
    true_neg = 0
    true_pos = 0
    false_pos = 0
    false_neg = 0
    if status == 'train':
        x_anomaly = x_train_anomaly
        x_normal = x_train_normal
    elif status == 'test':
        x_anomaly = x_test_anomaly
        x_normal = x_test_normal
    num_anomaly = np.shape(x_anomaly)[0]
    num_normal = np.shape(x_normal)[0]
    pred_anomaly = np.squeeze(D.predict(x_anomaly))
    pred_normal = np.squeeze(D.predict(x_normal))
    mean_ano = np.percentile(pred_anomaly, 50)
    mean_norm = np.percentile(pred_normal, 50)
    threshold = np.percentile(np.concatenate((pred_anomaly, pred_normal)), 20)
    for i in pred_anomaly:
        if i <= threshold:
            true_pos += 1
        elif i > threshold:
            false_neg +=1
    for j in pred_normal:
        if j >= threshold:
            true_neg += 1
        elif j < threshold:
            false_pos +=1
    '''
    plt.figure()
    plt.hist(pred_anomaly, density=True, bins=20, range=(0,1.0), label='anomaly', color='r', alpha=0.5)
    plt.hist(pred_normal, density=True, bins=20, range=(0,1.0), label='normal', color='b', alpha=0.5)
    #plt.axis([0, 1, 0, 1])
    plt.xlabel('Confidence')
    plt.ylabel('Probability')
    plt.title('Data: '+status+' Epoch: '+str(epoch)+' True Positive: '+str(round(true_pos/num_pic,1))+' True Negative: '+str(round(true_neg/num_pic,1)))
    plt.legend(loc=normal)
    plt.savefig(pic_path+status+'_histogram'+'_'+str(int(epoch/v_histogram))+'.png')
    plt.close()
    '''
    plt.figure()
    tp = plt.bar(0, true_pos)
    tn = plt.bar(5, true_neg)
    fp = plt.bar(10, false_pos)
    fn = plt.bar(15, false_neg)
    plt.ylabel('Number of True_Positive/True Negative')
    plt.legend((tp[0], tn[0], fp[0], fn[0]) , ('True Positive', 'True Negative', 'False Postive', 'False Negative'))
    plt.savefig(result_path+status+'_histogram'+'_'+str(int((epoch+1)/v_histogram))+'.png')
    plt.close()
    return true_pos/num_anomaly, true_neg/num_normal, false_pos/num_normal, false_neg/num_anomaly, mean_ano, mean_norm, true_pos, true_neg, false_pos, false_neg

def data(epoch, G):
    
    '''
    For Discriminator
    '''
    total = len(x_train_normal)
    offset = random.randint(0,total-batch_size)
    X_r = x_train_normal[offset:offset+batch_size,...]
    y_r = np.ones(batch_size)
    
    '''
    For Generator
    '''
    X_gen1 = noise_z(batch_size)
    y_gen1 = np.zeros(batch_size)
    y_gen1[:] = label_annealing(epoch, repeat, g_objective_anneal, baseline)
    
    X_gen2 = noise_z(batch_size)
    y_gen2 = np.zeros(batch_size)
    y_gen2[:] = label_annealing(epoch, repeat, g_objective_anneal, baseline)
    
    X_g = G.predict(X_gen1)
    y_g = np.zeros(batch_size)
    
    X_disc = np.concatenate((X_r, X_g), axis=0)
    y_disc = np.concatenate((y_r, y_g), axis=0)
    
    X_gen = np.concatenate((X_gen1, X_gen2), axis = 0)
    y_gen = np.concatenate((y_gen1, y_gen2), axis = 0)        
    
    return X_gen, y_gen, X_disc, y_disc

def disc_loss(y_true, y_pred):
    ratio = tf.shape(y_true)[0]//2
    loss_real = tf.reduce_mean(losses.binary_crossentropy(y_true[:ratio], y_pred[:ratio]))
    loss_gen = tf.reduce_mean(losses.binary_crossentropy(y_true[ratio:], y_pred[ratio:]))
    loss = loss_real + gen_weight * loss_gen
    return loss
def get_generative(lr_anneal):
    G_in = Input(shape=(z_dim,))
    x = Dense(64, activation='relu')(G_in)
    x = Dropout(dropout)(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(dropout)(x)
    x = Dense(121)(x)
    #G_out = Dropout(dropout)(x)
    G_out = x
    G = Model(G_in, G_out)
    #opt = Adam(lr=lr_anneal, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0, amsgrad=False)
    opt = Adam(lr=1e-4, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-3)
    G.compile(loss='binary_crossentropy', optimizer=opt)
    return G

def get_discriminative(dropout):
    D_in = Input(shape=(121,))
    x = Dense(256, kernel_regularizer=regularizers.l2(l2_reg))(D_in)
    x = LeakyReLU(alpha=0.1)(x)
    x = Dropout(dropout)(x)
    x = Dense(128, kernel_regularizer=regularizers.l2(l2_reg))(x)
    x = LeakyReLU(alpha=0.1)(x)
    x = Dropout(dropout)(x)
    x = Dense(128, kernel_regularizer=regularizers.l2(l2_reg))(x)
    x = LeakyReLU(alpha=0.1)(x)
    x = Dropout(dropout)(x)
    D_out = Dense(1, activation='sigmoid')(x)
    D = Model(D_in, D_out)
    dopt = SGD(lr=8e-6, decay=1e-3, momentum=0.9, nesterov=False)
    D.compile(loss='binary_crossentropy', optimizer=dopt)
    return D

def set_trainability(model, trainable=False): #alternate to freeze D network while training only G in (G+D) combination
    model.trainable = trainable
    for layer in model.layers:
        layer.trainable = trainable

def make_gan(G, D):  #making (G+D) framework
    set_trainability(D, False)
    GAN_in = Input(shape=(z_dim,))
    G_out = G(GAN_in)
    GAN_out = D(G_out)
    GAN = Model(GAN_in, GAN_out)
    GAN.compile(loss= loss_type(G_out, dispersion_weight, 0.2), optimizer=G.optimizer)
    return GAN

def pretrain( G, D): #pretrain D
    count = 1
    _, _, X, y = data(0, G)
    set_trainability(D, True)
    loss = D.train_on_batch(X, y)            
    print("Epoch #1: Loss: {}".format(loss))
    while (loss > 7):
        count +=1
        _, _, X, y = data(0, G)
        set_trainability(D, True)
        loss = D.train_on_batch(X, y)            
        print("Epoch #{}: Loss: {}".format(count, loss))        

def train(v_freq = 1):
    d_loss = []
    g_loss = []
    D = get_discriminative(dropout)
    G = get_generative(lr_anneal)
    GAN = make_gan(G, D)
    
    pretrain(G, D)
    steps_per_batch = np.shape(x_train_normal)[0] // batch_size

    for epoch in range(epochs):
        print("Epoch #{}/{}".format(epoch+1, epochs))
        for step in tqdm(range(steps_per_batch)):
            X_gen, y_gen, X_disc, y_disc = data(epoch, G)
            set_trainability(D, True)
            d_loss.append(D.train_on_batch(X_disc, y_disc))
            
            set_trainability(D, False)
            g_loss.append(GAN.train_on_batch(X_gen, y_gen))
        loss_d = np.percentile(np.asarray(d_loss), 50)
        loss_g = np.percentile(np.asarray(g_loss), 50)
        if (epoch + 1) % v_freq == 0:
            print("Epoch #{}/{}: Discriminator Loss: {}, Generator Loss: {}".format(epoch + 1, epochs, loss_d, loss_g))
            tp, tn, fp, fn, mean_ano, mean_norm, true_pos, true_neg, false_pos, false_neg = histogram(D, v_freq, 'test', epoch)
            print("mean_ano:", mean_ano)
            print("mean_norm:", mean_norm)
            print()
            config = configparser.ConfigParser()
            config['Results'] = {}
            config['Results']["True Positive"] = str(tp)
            config['Results']["True Negative"] = str(tn)
            config['Results']["False Positive"] = str(fp)
            config['Results']["False Negative"] = str(fn)
            if true_pos+false_pos == 0:
                config['Results']["Precision"] = str(0)
            else:
                config['Results']["Precision"] = str(true_pos/(true_pos+false_pos))
            if true_pos+false_neg == 0:
                config['Results']["Recall"] = str(0)
            else:
                config['Results']["Recall"] = str(true_pos/(true_pos+false_neg))
            if 2*true_pos+false_pos+false_neg == 0:
                config['Results']["F1 Score"] = str(0)
            else:
                config['Results']["F1 Score"] = str(2*true_pos / (2*true_pos+false_pos+false_neg))
            with open(result_path + '/epoch =  '+ str(epoch+1) + '_results.ini','w+') as configfile:
                config.write(configfile)

   
train()
config = configparser.ConfigParser()
epoch = []
precision = []
recall = []
f1 = []
for file in os.listdir(result_path):
    if file.split('.')[-1] == 'ini' and file != 'config.ini':
        config.read(result_path+file)
        epoch.append(int((file.split(' ')[-1]).split('_')[0]))
        precision.append(config['Results'].getfloat('precision'))
        recall.append(config['Results'].getfloat('recall'))
        f1.append(config['Results'].getfloat('f1 score'))
        
index = []
max_f1 = max(f1)
for i, j in enumerate(f1):
    if j == max_f1:
        index.append(i)
max_index = max(index)
max_epoch = (max_index+1) * 100
prec = precision[max_index]
rec = recall[max_index]

config = configparser.ConfigParser()
config['Final Results'] = {}
config['Final Results']["Max F1"] = str(max_f1)
config['Final Results']["Precision"] = str(prec)
config['Final Results']["Recall"] = str(rec)
config['Final Results']["Epoch"] = str(max_epoch)
with open(result_path + '/best_results.ini','w+') as configfile:
    config.write(configfile)
#Precision
fig1 = plt.figure()
plt.scatter(epoch, precision, label='Precision')
plt.title('Precision')
plt.xlabel('Epochs (Increment of 100)')
plt.ylabel('Percentage')
plt.legend()
plt.savefig(result_path+'Precision.jpg')
plt.close(fig1)

#Recall
fig2 = plt.figure()
plt.scatter(epoch, recall, label='Recall')
plt.title('Recall')
plt.xlabel('Epochs (Increment of 100)')
plt.ylabel('Percentage')
plt.legend()
plt.savefig(result_path+'Recall.jpg')
plt.close(fig2)

#F1 Score
fig3 = plt.figure()
plt.scatter(epoch, f1, label='F1 Score')
plt.title('F1 Score')
plt.xlabel('Epochs (Increment of 100)')
plt.ylabel('Percentage')
plt.legend()
plt.savefig(result_path+'F1 Score.jpg')
plt.close(fig3)
