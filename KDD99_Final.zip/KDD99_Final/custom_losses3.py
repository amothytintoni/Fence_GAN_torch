#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  5 10:38:45 2018

@author: root
"""
import configparser
import json
import sys
import torch
from torch import nn
# import tensorflow as tf
# from keras import losses
# import keras.backend as K

loss_dict = {'dispersion_loss': [], 'binary_loss': []}

# Average distance from the Center of Mass


def com(G_out, weight, round_up):
    def dispersion_loss(y_true, y_pred):

        loss_b = torch.mean(nn.BCEWithLogitsLoss()(
            y_pred.float(), y_true.float().view(-1, 1)))

        center = torch.mean(G_out, dim=0, keepdims=True)
        distance_xy = torch.square(torch.subtract(G_out, center))
        distance = torch.sum(distance_xy, 1)
        avg_distance = torch.mean(torch.sqrt(distance))
        loss_d = torch.reciprocal(avg_distance)

        loss_b_print = torch.clone(loss_b).detach().cpu().numpy()
        loss_d_print = torch.clone(loss_d).detach().cpu().numpy()
        print("binary_loss:", loss_b_print, "dispersion_loss:", loss_d_print,  end='\r')

        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss


# def tf_print(op, tensors, message=None):
#     def print_message(x):
#         #sys.stdout.write(message + " %s\n" % x)
#         loss_dict[message].append(float(x))
#         with open('loss.json','w+') as file:
#             json.dump(loss_dict, file, indent=4)
#         return x

#     prints = [tf.py_func(print_message, [tensor], tensor.dtype) for tensor in tensors]
#     with tf.control_dependencies(prints):
#         op = tf.identity(op)
#     return op
